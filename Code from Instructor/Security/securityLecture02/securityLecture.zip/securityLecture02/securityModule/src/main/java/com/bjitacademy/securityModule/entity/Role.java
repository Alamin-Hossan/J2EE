package com.bjitacademy.securityModule.entity;

public enum Role {
    USER,
    ADMIN;
}
